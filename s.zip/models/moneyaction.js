const { model, Schema } = require('mongoose')

module.exports = model("money-acction", new Schema({
    User: String,
    Daily: Number,
}))