const {model, Schema} = require('mongoose');

let leaveSchema = new Schema({
    Guild: String,
    Channel: String,
    Msg: String,
    UserID: String,

});

module.exports = model("Leave", leaveSchema);