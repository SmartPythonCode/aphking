const { Client, MembershipScreeningFieldType, ActionRow, GatewayIntentBits, ActivityType, EmbedBuilder, PermissionsBitField, Permissions, MessageManager, Embed, Collection, Events } = require(`discord.js`);
const fs = require('fs');



require('dotenv').config();





const client = new Client({
    intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildIntegrations,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildBans
  ],
          //intents and requirements
});



client.on("error", async (err) => {
        console.log(chalk.red(`[Dicord API Error]: ${err.message}`))
      })






client.commands = new Collection();



const functions = fs.readdirSync("./functions").filter(file => file.endsWith(".js"));
const eventFiles = fs.readdirSync("./events").filter(file => file.endsWith(".js"));
const commandFolders = fs.readdirSync("./commands");

(async () => {
    for (file of functions) {
        require(`./functions/${file}`)(client);
    }

    const { GiveawaysManager } = require("discord-giveaways");
    client.giveawaysManager = new GiveawaysManager(client, {
      storage: "./storage/giveaways.json",
      default: {
        botsCanWin: false,
        embedColor: "#2F3136",
        reaction: "🎉",
        lastChance: {
          enabled: true,
          content: `🛑 **Last chance to enter** 🛑`,
          threshold: 5000,
          embedColor: '#FF0000'
        }
      }
    });
    
    fs.readdir('./events/giveaway', (_err, files) => {
      files.forEach((file) => {
        if (!file.endsWith(".js")) return;
        const event = require(`./events/giveaway/${file}`);
        let eventName = file.split(".")[0];
        console.log(`[Event]   🎉 Loaded: ${eventName}`);
        client.giveawaysManager.on(eventName, (...file) => event.execute(...file, client)), delete require.cache[require.resolve(`./events/giveaway/${file}`)];
      })
    })

    client.handleEvents(eventFiles, "./events");
    client.handleCommands(commandFolders, "./commands");
    client.login(process.env.token)
})();

const { QuickDB } = require('quick.db');
const db = new QuickDB();

