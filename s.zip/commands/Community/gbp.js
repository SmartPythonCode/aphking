const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('convert-money')
        .setDescription('Convert currency from GBP.')
        .addStringOption(option =>
            option.setName('amount')
                .setDescription('The amount you wish to convert')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('currency')
                .setDescription('The currency you want to convert to')
                .addChoices(
                    { name: "USD", value: "usd" },
                    { name: "EURO", value: "euro" },
                    { name: "AUD", value: "aud" }
                )
                .setRequired(true)
        ),
    async execute(interaction) {
        const { options } = interaction;

        const amount = options.getString('amount');
        const currency = options.getString('currency');

        const embed = new EmbedBuilder()
        .setTitle(`Currency Converted💰`)
        .setColor('Red')
        .setTimestamp()

      try {

        switch (currency) {
            case "usd":
                const toUsd = amount * 1.21

                embed.addFields(
                    { name: "From GBP", value: `£${amount}`, inline: true },
                    { name: "To USD", value: `$${toUsd}`, inline: true }
                )
                break;
            case "euro":
                const toEuro = amount * 1.13

                embed.addFields(
                    { name: "From GBP", value: `£${amount}`, inline: true },
                    { name: "To EURO", value: `$${toEuro}`, inline: true }
                )
                break;
            case "aud":
                const toAUD = amount * 1.75

                embed.addFields(
                    { name: "From GBP", value: `£${amount}`, inline: true },
                    { name: "To AUD", value: `$${toAUD}`, inline: true }
                )

                break;
        }

        return interaction.reply({ embeds: [embed] })
       } catch (err) {
          console.log(err)
           interaction.reply({ content: "There has been an error"})
        }
    }
}