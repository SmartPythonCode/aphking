const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder, ChannelType } = require('discord.js');

module.exports = {
data: new SlashCommandBuilder()
    .setName('invite')
    .setDescription('create an instant invite for your server'),
async execute(interaction, guild) {
    
    const channel = interaction.guild.channels.cache.filter((channel) => channel.type === ChannelType.GuildText).first();
    const invite = await channel.createInvite({ maxAge: 0, maxUses: 0 })


    const embed = new EmbedBuilder()
    .setColor('Red')
    .setAuthor({ name: 'Success', iconURL: interaction.guild.iconURL({ dynamic: true})})
    .setDescription('This invite link will never expire')
    .addFields({ name: 'Invite', value: `${invite}`})

    await interaction.reply({ embeds: [embed] })
    }
};