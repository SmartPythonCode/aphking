const {Message, Client, SlashCommandBuilder, PermissionFlagsBits} = require("discord.js");
const leaveSchema = require("../../models/Leave");
const {model, Schema} = require("mongoose");
    
module.exports = {
    data: new SlashCommandBuilder()
    .setName("setup-leave")
    .setDescription("Set up your leave message for the discord bot.")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addChannelOption(option => 
        option.setName("channel")
        .setDescription("Channel for leave message.")
        .setRequired(true)
    )
    .addStringOption(option =>
        option.setName("message")
        .setDescription("Enter your leave message.")
        .setRequired(true)
    ),

    async execute(interaction) {
        const {channel, options} = interaction;

        const leavechannel = options.getChannel("channel");
        const message = options.getString("message");

        if(!interaction.guild.members.me.permissions.has(PermissionFlagsBits.Administrator)) {
            interaction.reply({content: "I don't have permissions for this.", ephemeral: true});
        }

        leaveSchema.findOne({Guild: interaction.guild.id}, async (err, data) => {
            if(!data) {
                const leave = await leaveSchema.create({
                    Guild: interaction.guild.id,
                    Channel: leavechannel.id,
                    Msg: message,
                    UserID: user.id,

                });
            }
            interaction.reply({content: 'The Leave Command Is Setup!', ephemeral: true});
        })
    }
}