const { SlashCommandBuilder } = require('@discordjs/builders');
const {EmbedBuilder} = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
    .setName('shlong')
    .setDescription('Gets your peener size'),

    async execute(interaction) {
        const length = Math.floor(Math.random()*15) + 1;
        const shaft = '='.repeat(length);
        const shlong = `8${shaft}D`

   interaction.reply({content: `${shlong}`});

    }

}