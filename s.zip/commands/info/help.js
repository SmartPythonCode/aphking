const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('This is the help command!'),
    async execute (interaction, client) {
        
        const embed = new EmbedBuilder()
        .setColor("Red")
        .setTitle("Heres what you need to know about alpha")
        .setDescription(`Help Command Guide:`)
        .addFields({ name: "Page 1", value: "Help & Resources (button1)"})
        .addFields({ name: "Page 2", value: "Community Commands (button2)"})
        .addFields({ name: "Page 3", value: "Moderation Commands (button3)"})
        .addFields({ name: "Page 4", value: "game commands (button4)"})

        const embed2 = new EmbedBuilder()
        .setColor("Red")
        .setTitle("Community Commands")
        .addFields({ name: "/help", value: "Do /help for the commands list & support"})
        .addFields({ name: "/ping", value: "Do /ping and the bot will reply with Pong!"})
        .addFields({ name: "/cats", value: "Do /cats and the bot will reply with a cat!"})
        .addFields({ name: "/doggy", value: "Do /doggy and the bot will reply with a dog!"})
        .addFields({ name: "/memes", value: "Do /memes and the bot will reply with a meme!"})
        .addFields({ name: "/poll", value: "Do /poll and the bot will make a poll!"})
        .addFields({ name: "/gbp", value: "Do /gbp and the bot will convert a currency!"})
        .addFields({ name: "/embed", value: "Do /ping and the bot will an embed for you!"})
        .addFields({ name: "/instantinvite", value: "Do /instantinvite and the bot will reply with the server invite!"})
        .addFields({ name: "/overview-info", value: "Do /overview-info and the bot will reply with the server icon and banner!"})
       
        .setFooter({ text: "Community Commands"})
        .setTimestamp()

        const embed3 = new EmbedBuilder()
        .setColor("Red")
        .setTitle("Moderation Commands")
        .addFields({ name: "/ban", value: "Do /ban to ban a member"})
        .addFields({ name: "/unban", value: "Do /unban to unban a member"})
        .addFields({ name: "/kick", value: "Do /kick to kick a member"})
        .addFields({ name: "/timeout", value: "Do /timeout to mute a member"})
        .addFields({ name: "/slowmode", value: "Do /slowmode to stop spam in a certain channel"})
        .addFields({ name: "/clear", value: "Do /clear to delete a certain amount of messages"})
        
        .setFooter({ text: "moderation Commands"})
        .setTimestamp()

        const embed4 = new EmbedBuilder()
        .setColor("Red")
        .setTitle("game commands")
        .addFields({ name: "/8ball", value: "Do /8ball to have fun"})
        .addFields({ name: "/coinflip", value: "Do /coinflip to flip a coin"})
        .addFields({ name: "/shlong", value: "Do /shlong to find out ur pp size"})
        .addFields({ name: "/steal", value: "Do /steal to nab a server emoji and it to yours!"})
        .addFields({ name: "/wouldyourather", value: "Do /wouldyourather to have some fun with friends!"})
       
        .setFooter({ text: "game commands"})
        .setTimestamp()

        const button = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
            .setCustomId(`page1`)
            .setLabel(`Page 1`)
            .setStyle(ButtonStyle.Success),

            new ButtonBuilder()
            .setCustomId(`page2`)
            .setLabel(`Page 2`)
            .setStyle(ButtonStyle.Success),

            new ButtonBuilder()
            .setCustomId(`page3`)
            .setLabel(`Page 3`)
            .setStyle(ButtonStyle.Success),

            new ButtonBuilder()
            .setCustomId(`page4`)
            .setLabel(`Page 4`)
            .setStyle(ButtonStyle.Success)
        )

        const message = await interaction.reply({ embeds: [embed], components: [button] });
        const collector = await message.createMessageComponentCollector();

        collector.on('collect', async i => {
            
            if (i.customId === 'page1') {
                
                if (i.user.id !== interaction.user.id) {
                    return await i.reply({ content: `Only ${interaction.user.tag} can use these buttons!`, ephemeral: true})
                }
                await i.update({ embeds: [embed], components: [button] })
            }

            if (i.customId === 'page2') {
                
                if (i.user.id !== interaction.user.id) {
                    return await i.reply({ content: `Only ${interaction.user.tag} can use these buttons!`, ephemeral: true})
                }
                await i.update({ embeds: [embed2], components: [button] })
            }

            if (i.customId === 'page3') {
                
                if (i.user.id !== interaction.user.id) {
                    return await i.reply({ content: `Only ${interaction.user.tag} can use these buttons!`, ephemeral: true})
                }
                await i.update({ embeds: [embed3], components: [button] })
            }
            if (i.customId === 'page4') {
                
                if (i.user.id !== interaction.user.id) {
                    return await i.reply({ content: `Only ${interaction.user.tag} can use these buttons!`, ephemeral: true})
                }
                await i.update({ embeds: [embed4], components: [button] })
            }
        })


    }
}