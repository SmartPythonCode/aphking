const { SlashCommandBuilder, EmbedBuilder, ButtonBuilder, PermissionFlagsBits, ButtonStyle, ActionRowBuilder } = require("discord.js");
const suggestionSchema = require("../../models/Suggest");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("suggest")
        .setDescription("Place a suggestion.")
        .addStringOption(option =>
            option.setName("name")
                .setDescription("Name Your Suggestion")
                .setRequired(true)       
        )
        .addStringOption(option =>
            option.setName("description")
                .setDescription("Describe your suggestion clearly.")
                .setRequired(true)
        ),

    async execute(interaction) {
        const { guild, options, member } = interaction;

        const name = options.getString("name");
        const description = options.getString("description");

        const embed = new EmbedBuilder()
            .setColor("Green")
          .setDescription(`A Suggestion Made By ${member}`)
            .addFields(
                { name: "Suggestion:", value: `${name}`},
              { name: "Description:", value: `${description}` },
            )
      .setFooter( { text: member.user.tag, iconURL: member.displayAvatarURL ({ dynamic: true}) })
      await guild.channels.cache.get('1058549060874797159').send({
        embeds: ([embed]),
      }).then((s) => {
        s.react('✅');
        s.react('❌');
      }).catch((err) => {
      throw err;  
      });

      interaction.reply({ content: ":white_check_mark: | Your Suggestion Has Been Submitted", ephemeral: true })
      }
    }