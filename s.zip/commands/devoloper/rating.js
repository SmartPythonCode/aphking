const {
    SlashCommandBuilder,
    EmbedBuilder,
    PermissionFlagsBits,
  } = require("discord.js");
  
  module.exports = {
    data: new SlashCommandBuilder()
      .setName("review")
      .setDescription("Leave a review in our reviews channel!")
      .setDefaultMemberPermissions(PermissionFlagsBits.SendMessages)
      .addStringOption((option) =>
        option
          .setName("stars")
          .setDescription("Amount of stars.")
          .setRequired(true)
          .addChoices(
            { name: "⭐", value: "⭐" },
            { name: "⭐⭐", value: "⭐⭐" },
            { name: "⭐⭐⭐", value: "⭐⭐⭐" },
            { name: "⭐⭐⭐⭐", value: "⭐⭐⭐⭐" },
            { name: "⭐⭐⭐⭐⭐", value: "⭐⭐⭐⭐⭐" }
          )
      )
      .addStringOption((option) =>
        option
          .setName("description")
          .setDescription("Description of your review.")
          .setRequired(true)
      ),
    async execute(interaction, client) {
      const { options, guild } = interaction;
      const stars = options.getString("stars");
      const desc = options.getString("description");
  
      const ID = "1073296786405462056"; // add the id of the channel where the message is sent.
      const ROLE = "1048666749110861874"; // add the role that can use the command.
  
      if (!interaction.member.roles.cache.has(ROLE)) {
        return interaction.reply({
          content: ":x: You do not have permission to use this command.",
          ephemeral: true,
        });
      }
  
      const embed = new EmbedBuilder()
        .setAuthor({
          name: interaction.user.tag,
          iconURL: interaction.user.displayAvatarURL({ dynamic: true }),
        })
        .addFields([
          {
            name: "Stars",
            value: `${stars}`,
          },
          {
            name: "Review",
            value: `${desc}`,
          },
        ])
        .setColor("Blue")
        .setTimestamp();
  
      guild.channels.cache.get(ID).send({
        embeds: [embed],
      });
  
      await interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setDescription("your review was submitted successfully.")
            .setColor("Green"),
        ],
        ephemeral: true,
      });
    },
  };
  