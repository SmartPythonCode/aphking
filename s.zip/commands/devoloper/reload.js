const { EmbedBuilder } = require('@discordjs/builders');
const { Client, SlashCommandBuilder, PermissionFlagsBits, ChatInputCommandInteraction } = require('discord.js')
const { handelCommands } = require('../../functions/handelCommands')
const { handelEvents } = require('../../functions/handelEvents')

module.exports = {
    data: new SlashCommandBuilder()
    .setName("reload")
    .setDescription("Reload your events/command!")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(
        command => 
        command.setName("events")
        .setDescription("Reload your events!"))
    .addSubcommand(
        command => 
        command.setName("commands")
        .setDescription("Reload your commands!")),
    developer: true,
    /**
     * @param { ChatInputCommandInteraction } interaction
     */
    async execute(interaction, client) {

        const sub = interaction.options.getSubcommand();
        const Response = new EmbedBuilder()
        .setTitle("💻 Developer")
        .setColor(client.mainColor)

        switch (sub) {
            case "commands": {
                handelCommands(client);
                interaction.reply({embeds: [Response.setDescription("✅ Reloaded Commands!")]})
            }
            break;
        
            case "events": {
                handelEvents(client);
                interaction.reply({embeds: [Response.setDescription("✅ Reloaded Events!")]})
            }
            break;
        }

    },
}