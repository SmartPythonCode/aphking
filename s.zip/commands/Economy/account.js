const { EmbedBuilder } = require("@discordjs/builders")
const { SlashCommandBuilder, Client, ChatInputCommandInteraction } = require("discord.js")
const AccountDB = require('../../models/account')


module.exports = {
    data: new SlashCommandBuilder()
    .setName("economy")
    .setDescription("Translate any text to a specific language!")
    .addStringOption(
        option =>
        option.setName("optionss")
        .setDescription("The language you wanna translate to!")
        .addChoices(
            { name: "Create", value: "create"},
            { name: "Bal", value: "bal"},
            { name: "Delete", value: "delete"},
        ).setRequired(true)),

async excucte(interaction) {
    const { options, user} = interaction
 
    let Data = await AccountDB.findOne({ User: user.id}).catch(err => { })
    
    const optionss = options.getString("optionss")

    switch (optionss) {
        case "create": {
            if (Data) return interaction.reply({ content: `You Already Have An Account! ${user}`})

          await interaction.deferReply()

          Data = new AccountDB({
            User: user.id,
            Bank: 5000,
            Wallet: 1000
          })
 await Data.save()
 const embed = new EmbedBuilder()
 .setColor('Green')
 .setDescription(":white_check_mark: Your Account Has Been Made")

 interaction.channel.send({ embeds: [embed] })
        }

        break;

        
}
switch (optionss) {

case "balance": {
    if (!Data) return interaction.reply({ content: `Please Create An Account! ${user}`, enphermal: true})

  await interaction.deferReply()

    interaction.editReply({
        embeds: [
            new EmbedBuilder()
            .setColor('Orange')
            .setTitle("Balance")
            .setDescription(`**Wallet** $${Data.Wallet}\n **Bank** $${Data.Bank}\n **Total** $${Data.Wallet + Data.Bank}`)
        ]
    })
break;
}

    case "delete": {
        if (!Data) return interaction.reply({ content: `Please Create An Account! ${user}`, enphermal: true})
    
      await interaction.deferReply()
    
    await Data.delete()

        interaction.reply({
            embeds: [
                new EmbedBuilder()
                .setColor('Green')
                .setTitle("Deleted")
                .setDescription(`${user} You Account Has Been Deleted`)
            ]
        })
    break;
}
}
}
} // Delete