
const { discordSort, Message } = require("discord.js");

const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, ButtonInteraction, PermissionsBitField } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
    .setName('setup-ticket')
    .setDescription('Use this commanbd to setup the tickets'),
    async execute (interaction, client) {

        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return await interaction.reply({ content: "You must be a Staff Commander or a Head Developer to create a ticket message"})

        const button = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
            .setCustomId('button')
            .setLabel('Create Ticket')
            .setStyle(ButtonStyle.Secondary), 
        )
        
        const close = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
            .setCustomId('close')
            .setLabel('Close Ticket')
            .setStyle(ButtonStyle.Secondary), 
        )

        const embed = new EmbedBuilder()
        .setColor("BLUE")
        .setTitle("Tickets & Support")
      .setDescription("Press The Create A Ticket Button To Create A Ticket (Staff Will Be At Your Ticket Soon) ")


      const inticket = new EmbedBuilder()
      .setColor('DarkButNotBlack')
      .setTitle(`Welcome To Ticket`)
    .setDescription(`Welcome To The Ticket Someone Will Be Here Soon`)

   const embed3 = new EmbedBuilder()
   .setColor('Aqua')
   .setDescription("Closing Ticket")
    

        await interaction.reply({ embeds: [embed],components: [button] });
    
    


        const collector = await interaction.channel.createMessageComponentCollector();

        collector.on('collect', async i => {
if (i.customId === 'button') {
            const channel = await interaction.guild.channels.create({
                name: `ticket ${i.user.tag}`, 
                type: ChannelType.GuildText
            });
      
            channel.permissionOverwrites.create(i.user.id, { ViewChannel: true,            SendMessages: true} );
            channel.permissionOverwrites.create(i.guild.id, { ViewChannel: false, SendMessages: false} );


            channel.send({ embeds: [inticket],components: [close] });
            
            channel.send({ content: `${i.user}`})
        }
            if (i.customId === 'close') {
                
                await i.update({embeds: [embed3], components: [close]})
            }
 
            });

            collector.on("end", async (collected) => {
              console.log(':)')
            
        })
    }
}