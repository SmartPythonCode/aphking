const { Client, ActivityType } = require("discord.js");
const { activityInterval, database } = require('../config.json')
const mongoose = require('mongoose')

module.exports = {
  name: "ready",
  rest: false,
  once: false,
  /**
   * @param {Client} client
   */
  async execute(client) {

    /* Connect to database */
    if(!database) return;
    mongoose.connect(database, {}).then(() => console.log("The client is now connected to the database!")  
    ).catch((err) => console.error(err))
client.user.setPresence({
            activities: [{ name: `we `, type: ActivityType.Listening }],
            status: 'idle',
        });
    console.log(
      `Logged in as ${client.user.tag} and running on ${client.guilds.cache.size} Server!`
    );
  },
};